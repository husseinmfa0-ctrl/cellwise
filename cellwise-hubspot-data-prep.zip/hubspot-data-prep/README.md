# Cellwise — Enterprise AI Data Preparation for CRM Teams

Turns a client's messy Excel/CSV export into a clean, HubSpot-ready CSV,
with a live "AI Operations Terminal" that shows genuine per-batch processing
output, a before/after split view with fix badges, and an ROI summary card —
built for HubSpot Solutions Partner agencies evaluating this seriously, not
a quick demo.

```
messy .csv/.xlsx → Next.js (SSE client) → FastAPI (batches + streams) → Gemini 1.5 Flash
                                                    │
                                    real MX-record email validation (DNS)
                                                    │
                              ← live terminal log, badges, stats, CSV export
```

## Quickstart (both servers)

**Terminal 1 — backend**
```bash
cd backend
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # add your GEMINI_API_KEY
uvicorn main:app --reload --port 8000
```

**Terminal 2 — frontend**
```bash
cd frontend
npm install
cp .env.local.example .env.local
npm run dev
```

Open http://localhost:3000, drop in a messy spreadsheet, and watch the
terminal, then download the cleaned CSV.

## What's already verified

- **Backend**: dependencies install cleanly; the FastAPI app imports and its
  routes register; the full SSE pipeline was tested end-to-end (with the
  Gemini call itself mocked, since I don't have your API key) — header
  mapping, phone/name badges, and **real DNS MX-record lookups** were all
  confirmed correct against live domains (`gmail.com` resolved valid, a
  nonexistent domain correctly resolved invalid). `export-csv` was confirmed
  to strip internal fields (`_badges`, `Mx_Valid`) before generating the
  HubSpot import file.
- **Frontend**: `npm run build` compiles clean on Next.js 16 / React 19 with
  zero type errors; the client-side SSE buffer-parser was separately unit
  tested against artificially split network chunks to confirm it doesn't
  drop or corrupt events at awkward boundaries; the production standalone
  server was run directly and confirmed to serve the real page.
- **Not yet tested against the real Gemini API**, since I don't have your
  key — plug it in and the same pipeline runs for real. If Gemini's actual
  JSON shape ever drifts from what's documented in `backend/README.md`,
  `cleaner.py` has fallbacks for the most likely variations, but it's worth
  a real test run before you demo this to a client.

## About the GitHub repo

I can't create or push to a GitHub repo under your account — I don't have
your credentials. What's in this zip is a fully initialized local git repo
(`git log` will show the commit) so you can push it in three commands:

```bash
cd cellwise-hubspot-data-prep
git remote add origin https://github.com/<your-username>/<your-repo>.git
git branch -M main
git push -u origin main
```

Create the empty repo on GitHub first (no README/gitignore, so it doesn't
conflict with what's already committed here).

## Deploying it

Full step-by-step instructions (Vercel for the frontend, Render or Railway
for the backend) are in **[DEPLOYMENT.md](./DEPLOYMENT.md)**. Same configs
as before — `render.yaml`, `backend/railway.toml` + `backend/Dockerfile`,
`frontend/Dockerfile`, `docker-compose.yml` — nothing there needed to change
for this UI/backend upgrade, since env vars (`GEMINI_API_KEY`,
`ALLOWED_ORIGINS`, `NEXT_PUBLIC_API_URL`) are unchanged. One addition worth
knowing: the processing terminal depends on Server-Sent Events streaming
correctly through your host — Render and Railway both support this with no
extra config, but if the terminal seems to freeze and then dump everything
at once after deploying, check your host's proxy isn't buffering the
response.

## What's next (not built yet)

- Auth / accounts (still single-user, no login)
- Persistent storage of past uploads/exports
- Retry/backoff on Gemini rate limits for very large files
- Real end-to-end test against the live Gemini API (needs your key)

## Repo layout

```
backend/    FastAPI + Gemini cleaning engine + real MX validation  (see backend/README.md)
frontend/   Next.js + Tailwind enterprise UI + SSE terminal        (see frontend/README.md)
render.yaml, docker-compose.yml, DEPLOYMENT.md   deployment configs/guide
```
