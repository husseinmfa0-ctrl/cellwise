"use client";

import { useRef, useState } from "react";
import Dropzone from "@/components/Dropzone";
import PreviewTable from "@/components/PreviewTable";
import Terminal, { LogLine } from "@/components/Terminal";
import AnalyticsSummary, { Stats } from "@/components/AnalyticsSummary";

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

type Status = "idle" | "processing" | "done" | "error";

type ResultPayload = {
  filename: string;
  row_count: number;
  original_preview: Record<string, unknown>[];
  cleaned: Record<string, unknown>[];
  stats: Stats;
};

function timestamp(): string {
  return new Date().toLocaleTimeString("en-GB", { hour12: false });
}

export default function Home() {
  const [status, setStatus] = useState<Status>("idle");
  const [logs, setLogs] = useState<LogLine[]>([]);
  const [batchLabel, setBatchLabel] = useState<string | undefined>(undefined);
  const [result, setResult] = useState<ResultPayload | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isDownloading, setIsDownloading] = useState(false);
  const logIdRef = useRef(0);

  const appendLog = (message: string) => {
    logIdRef.current += 1;
    setLogs((prev) => [...prev, { id: logIdRef.current, message, timestamp: timestamp() }]);
  };

  const handleFile = async (file: File) => {
    setStatus("processing");
    setLogs([]);
    setBatchLabel(undefined);
    setErrorMessage(null);
    setResult(null);
    logIdRef.current = 0;

    let meta: { filename: string; row_count: number; original_preview: Record<string, unknown>[] } | null = null;

    try {
      const formData = new FormData();
      formData.append("file", file);

      const res = await fetch(`${API_URL}/api/clean-stream`, { method: "POST", body: formData });
      if (!res.ok || !res.body) {
        throw new Error(`Server responded with ${res.status}`);
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      appendLog(`Connected to processing pipeline for "${file.name}".`);

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        const events = buffer.split("\n\n");
        buffer = events.pop() || "";

        for (const raw of events) {
          if (!raw.trim()) continue;
          const eventMatch = raw.match(/^event:\s*(.+)$/m);
          const dataMatch = raw.match(/^data:\s*(.+)$/m);
          if (!eventMatch || !dataMatch) continue;

          const eventType = eventMatch[1].trim();
          const data = JSON.parse(dataMatch[1]);

          if (eventType === "meta") {
            meta = data;
          } else if (eventType === "log") {
            appendLog(data.message);
          } else if (eventType === "batch_done") {
            setBatchLabel(`batch ${data.batch}/${data.of}`);
          } else if (eventType === "result") {
            if (!meta) throw new Error("Stream ended without file metadata.");
            appendLog("Done. HubSpot-ready CSV is ready for export.");
            setResult({
              filename: meta.filename,
              row_count: meta.row_count,
              original_preview: meta.original_preview,
              cleaned: data.cleaned,
              stats: data.stats,
            });
            setStatus("done");
          } else if (eventType === "error") {
            throw new Error(data.detail || "Something went wrong while cleaning the file.");
          }
        }
      }
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : "Unexpected error.");
      setStatus("error");
    }
  };

  const handleDownload = async () => {
    if (!result) return;
    setIsDownloading(true);
    try {
      const res = await fetch(`${API_URL}/api/export-csv`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rows: result.cleaned }),
      });
      if (!res.ok) return;
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "hubspot_ready_contacts.csv";
      a.click();
      URL.revokeObjectURL(url);
    } finally {
      setTimeout(() => setIsDownloading(false), 400);
    }
  };

  const reset = () => {
    setStatus("idle");
    setLogs([]);
    setResult(null);
    setErrorMessage(null);
  };

  return (
    <main className="mx-auto flex min-h-screen max-w-5xl flex-col gap-10 px-6 py-16">
      <div className="flex items-center justify-between">
        <span className="font-display text-lg font-medium text-ink">Cellwise</span>
        <span className="rounded-full border border-border bg-surface px-3 py-1 font-mono text-[11px] uppercase tracking-widest text-inkmuted">
          Enterprise
        </span>
      </div>

      <section className="flex flex-col items-start gap-4">
        <span className="font-mono text-xs uppercase tracking-widest text-violet">
          for HubSpot solutions partners
        </span>
        <h1 className="font-display text-4xl font-bold leading-tight text-ink sm:text-5xl">
          Enterprise AI Data Preparation
          <br />
          for CRM Teams.
        </h1>
        <p className="max-w-xl text-base text-inkmuted">
          Upload messy client spreadsheets. Restructure, validate, and format contacts for
          HubSpot in seconds, with zero manual formulas.
        </p>
      </section>

      <section className="flex flex-col gap-6">
        {status === "idle" && <Dropzone onFileSelected={handleFile} />}

        {status === "processing" && (
          <div className="flex flex-col gap-3">
            <p className="font-display text-lg font-medium text-ink">
              AI is restructuring and validating your contacts…
            </p>
            <Terminal logs={logs} batchLabel={batchLabel} />
          </div>
        )}

        {status === "error" && (
          <div className="flex flex-col gap-3 rounded-xl border border-rose/30 bg-rose-bg/40 px-6 py-8">
            <p className="font-display text-base font-medium text-rose">
              Couldn&apos;t clean that file
            </p>
            <p className="text-sm text-ink/90">{errorMessage}</p>
            <button
              onClick={reset}
              className="w-fit rounded-md border border-border bg-surface px-4 py-2 text-sm font-medium text-ink hover:bg-surface2"
            >
              Try another file
            </button>
          </div>
        )}

        {status === "done" && result && (
          <div className="flex flex-col gap-6">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <p className="text-sm text-inkmuted">
                <span className="font-mono text-ink">{result.filename}</span> —{" "}
                {result.row_count} rows cleaned
              </p>
              <button
                onClick={reset}
                className="rounded-md border border-border bg-surface px-4 py-2 text-sm font-medium text-ink hover:bg-surface2"
              >
                Upload another
              </button>
            </div>

            <AnalyticsSummary stats={result.stats} />

            <PreviewTable
              original={result.original_preview}
              cleaned={result.cleaned.slice(0, 10)}
            />

            <button
              onClick={handleDownload}
              className={`w-fit rounded-md bg-emerald px-6 py-3 font-display text-sm font-medium text-[#04231A] transition-transform hover:bg-emerald-dark ${
                isDownloading ? "download-pulse" : ""
              }`}
            >
              {isDownloading ? "Preparing export…" : "Export HubSpot-ready CSV"}
            </button>
          </div>
        )}
      </section>
    </main>
  );
}
