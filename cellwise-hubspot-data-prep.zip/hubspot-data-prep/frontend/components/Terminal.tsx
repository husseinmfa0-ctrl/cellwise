"use client";

import { useEffect, useRef } from "react";

export type LogLine = {
  id: number;
  message: string;
  timestamp: string;
};

function lineColor(message: string): string {
  if (message.startsWith("Header mapping")) return "text-violet";
  if (message.startsWith("Email validation") || message.includes("flagged")) return "text-rose";
  if (message.startsWith("Phone standardization") || message.startsWith("Validating MX")) {
    return "text-emerald";
  }
  return "text-inkmuted";
}

export default function Terminal({
  logs,
  batchLabel,
}: {
  logs: LogLine[];
  batchLabel?: string;
}) {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [logs.length]);

  return (
    <div className="overflow-hidden rounded-xl border border-border bg-[#080A0E]">
      <div className="flex items-center justify-between border-b border-border bg-surface px-4 py-2.5">
        <div className="flex items-center gap-2">
          <span className="h-2.5 w-2.5 rounded-full bg-rose/70" />
          <span className="h-2.5 w-2.5 rounded-full bg-[#F5B94B]/70" />
          <span className="h-2.5 w-2.5 rounded-full bg-emerald/70" />
          <span className="ml-3 font-mono text-xs text-inkmuted">ai-operations-terminal</span>
        </div>
        {batchLabel && (
          <span className="font-mono text-[11px] uppercase tracking-wide text-inkfaint">
            {batchLabel}
          </span>
        )}
      </div>
      <div ref={scrollRef} className="max-h-72 overflow-y-auto px-4 py-4">
        {logs.map((log) => (
          <div key={log.id} className="log-line flex gap-3 py-0.5 font-mono text-[13px] leading-relaxed">
            <span className="shrink-0 text-inkfaint">[{log.timestamp}]</span>
            <span className={lineColor(log.message)}>{log.message}</span>
          </div>
        ))}
        <div className="flex items-center gap-2 pt-1">
          <span className="font-mono text-[13px] text-emerald">{">"}</span>
          <span className="terminal-cursor h-3.5 w-2 bg-emerald/70" />
        </div>
      </div>
    </div>
  );
}
