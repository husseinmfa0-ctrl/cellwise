export type Stats = {
  total_rows: number;
  headers_mapped: number;
  phone_numbers_fixed: number;
  invalid_emails_caught: number;
  names_split: number;
  estimated_hours_saved: number;
  assumed_seconds_per_row: number;
};

function Tile({
  label,
  value,
  accent,
  delay,
}: {
  label: string;
  value: string;
  accent?: "emerald" | "violet" | "rose";
  delay: number;
}) {
  const accentClass =
    accent === "emerald" ? "text-emerald" : accent === "violet" ? "text-violet" : accent === "rose" ? "text-rose" : "text-ink";

  return (
    <div
      className="stat-in rounded-xl border border-border bg-surface p-4"
      style={{ animationDelay: `${delay}ms` }}
    >
      <p className="font-mono text-[11px] uppercase tracking-widest text-inkfaint">{label}</p>
      <p className={`mt-1.5 font-display text-3xl font-medium ${accentClass}`}>{value}</p>
    </div>
  );
}

export default function AnalyticsSummary({ stats }: { stats: Stats }) {
  return (
    <div>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Tile label="Rows processed" value={stats.total_rows.toLocaleString()} delay={0} />
        <Tile
          label="Headers auto-mapped"
          value={stats.headers_mapped.toLocaleString()}
          accent="violet"
          delay={60}
        />
        <Tile
          label="Invalid emails caught"
          value={stats.invalid_emails_caught.toLocaleString()}
          accent="rose"
          delay={120}
        />
        <Tile
          label="Est. hours saved"
          value={`${stats.estimated_hours_saved}h`}
          accent="emerald"
          delay={180}
        />
      </div>
      <p className="mt-2 font-mono text-[11px] text-inkfaint">
        Hours-saved estimate assumes ~{stats.assumed_seconds_per_row}s of manual cleanup per
        contact row.
      </p>
    </div>
  );
}
