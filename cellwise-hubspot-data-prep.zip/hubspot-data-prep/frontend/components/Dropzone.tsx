"use client";

import { useCallback, useRef, useState } from "react";

type DropzoneProps = {
  onFileSelected: (file: File) => void;
  disabled?: boolean;
};

const ACCEPTED_EXTENSIONS = [".csv", ".xlsx", ".xls"];

export default function Dropzone({ onFileSelected, disabled }: DropzoneProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const validateAndSend = useCallback(
    (file: File) => {
      const lower = file.name.toLowerCase();
      const isAccepted = ACCEPTED_EXTENSIONS.some((ext) => lower.endsWith(ext));
      if (!isAccepted) {
        setError("That file type isn't supported. Upload a .csv or .xlsx file.");
        return;
      }
      setError(null);
      onFileSelected(file);
    },
    [onFileSelected]
  );

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    if (disabled) return;
    const file = e.dataTransfer.files?.[0];
    if (file) validateAndSend(file);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) validateAndSend(file);
    e.target.value = "";
  };

  return (
    <div>
      <div
        role="button"
        tabIndex={0}
        aria-disabled={disabled}
        onClick={() => !disabled && inputRef.current?.click()}
        onKeyDown={(e) => {
          if ((e.key === "Enter" || e.key === " ") && !disabled) inputRef.current?.click();
        }}
        onDragOver={(e) => {
          e.preventDefault();
          if (!disabled) setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        className={`group relative flex flex-col items-center justify-center gap-3 rounded-xl border px-8 py-16 text-center transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald focus-visible:ring-offset-2 focus-visible:ring-offset-canvas ${
          disabled
            ? "cursor-not-allowed border-border bg-surface/40 opacity-50"
            : isDragging
            ? "glow-active cursor-pointer border-emerald/60 bg-emerald/[0.04]"
            : "cursor-pointer border-border bg-surface hover:border-border-strong hover:bg-surface2"
        }`}
      >
        <input
          ref={inputRef}
          type="file"
          accept=".csv,.xlsx,.xls"
          className="hidden"
          onChange={handleChange}
          disabled={disabled}
        />
        <div
          className={`flex h-12 w-12 items-center justify-center rounded-full border transition-colors ${
            isDragging ? "border-emerald/50 bg-emerald/10" : "border-border-strong bg-surface2"
          }`}
        >
          <svg
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            className={isDragging ? "text-emerald" : "text-inkmuted"}
          >
            <path
              d="M12 16V4M12 4L7 9M12 4L17 9M5 16v2a2 2 0 002 2h10a2 2 0 002-2v-2"
              stroke="currentColor"
              strokeWidth="1.6"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>
        <p className="font-display text-lg font-medium text-ink">
          Drag a messy .csv or .xlsx here
        </p>
        <p className="text-sm text-inkmuted">or click to browse your files</p>
        <span className="mt-1 font-mono text-[11px] uppercase tracking-widest text-inkfaint">
          10MB max · .csv .xlsx .xls
        </span>
      </div>
      {error && <p className="mt-2 text-sm text-rose">{error}</p>}
    </div>
  );
}
