type Row = Record<string, unknown>;

function Badge({ text }: { text: string }) {
  const colorClass = text.startsWith("Email")
    ? "bg-rose-bg text-rose border-rose/30"
    : text.startsWith("Phone")
    ? "bg-emerald-bg text-emerald border-emerald/30"
    : "bg-violet-bg text-violet border-violet/30";

  // Show only the part after the colon (field label is redundant with the column already shown)
  const label = text.includes(":") ? text.split(":").slice(1).join(":").trim() : text;

  return (
    <span
      className={`inline-block whitespace-nowrap rounded-full border px-2 py-0.5 font-mono text-[10px] ${colorClass}`}
    >
      {label}
    </span>
  );
}

function BeforePane({ rows }: { rows: Row[] }) {
  const columns = rows.length > 0 ? Object.keys(rows[0]) : [];

  return (
    <div className="flex-1 overflow-hidden rounded-xl border border-rose/20 bg-rose-bg/30">
      <div className="flex items-center justify-between border-b border-rose/20 bg-rose-bg/50 px-4 py-2.5">
        <span className="font-display text-sm font-medium text-ink">Before — raw import</span>
        <span className="font-mono text-[11px] text-rose/80">as received</span>
      </div>
      <div className="max-h-96 overflow-auto">
        <table className="w-full text-left text-sm">
          <thead className="sticky top-0 bg-rose-bg/60 backdrop-blur">
            <tr>
              {columns.map((col) => (
                <th
                  key={col}
                  className="whitespace-nowrap border-b border-rose/20 px-3 py-2 font-mono text-[11px] font-medium uppercase tracking-wide text-inkmuted"
                >
                  {col}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row, i) => (
              <tr key={i} className="cell-settle" style={{ animationDelay: `${i * 30}ms` }}>
                {columns.map((col) => (
                  <td
                    key={col}
                    className="whitespace-nowrap border-b border-rose/10 px-3 py-2 font-mono text-xs text-ink/80"
                  >
                    {String(row[col] ?? "")}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function AfterPane({ rows }: { rows: Row[] }) {
  const displayColumns = ["First Name", "Last Name", "Email", "Phone Number", "Is_Valid_Email"];

  return (
    <div className="flex-1 overflow-hidden rounded-xl border border-emerald/20 bg-emerald-bg/30">
      <div className="flex items-center justify-between border-b border-emerald/20 bg-emerald-bg/50 px-4 py-2.5">
        <span className="font-display text-sm font-medium text-ink">After — HubSpot ready</span>
        <span className="font-mono text-[11px] text-emerald/80">AI cleaned</span>
      </div>
      <div className="max-h-96 overflow-auto">
        <table className="w-full text-left text-sm">
          <thead className="sticky top-0 bg-emerald-bg/60 backdrop-blur">
            <tr>
              {displayColumns.map((col) => (
                <th
                  key={col}
                  className="whitespace-nowrap border-b border-emerald/20 px-3 py-2 font-mono text-[11px] font-medium uppercase tracking-wide text-inkmuted"
                >
                  {col}
                </th>
              ))}
              <th className="whitespace-nowrap border-b border-emerald/20 px-3 py-2 font-mono text-[11px] font-medium uppercase tracking-wide text-inkmuted">
                Fixes
              </th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row, i) => {
              const badges = Array.isArray(row["_badges"]) ? (row["_badges"] as string[]) : [];
              return (
                <tr key={i} className="cell-settle" style={{ animationDelay: `${i * 30}ms` }}>
                  {displayColumns.map((col) => {
                    const value = row[col];
                    const isValidityFlag = col === "Is_Valid_Email";
                    return (
                      <td
                        key={col}
                        className={`whitespace-nowrap border-b border-emerald/10 px-3 py-2 font-mono text-xs ${
                          isValidityFlag ? (value ? "text-emerald" : "text-rose") : "text-ink/90"
                        }`}
                      >
                        {isValidityFlag ? (value ? "valid" : "flagged") : String(value ?? "")}
                      </td>
                    );
                  })}
                  <td className="whitespace-nowrap border-b border-emerald/10 px-3 py-2">
                    <div className="flex flex-wrap gap-1">
                      {badges.map((b, j) => (
                        <Badge key={j} text={b} />
                      ))}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default function PreviewTable({ original, cleaned }: { original: Row[]; cleaned: Row[] }) {
  return (
    <div className="flex flex-col gap-4 md:flex-row">
      <BeforePane rows={original} />
      <AfterPane rows={cleaned} />
    </div>
  );
}
