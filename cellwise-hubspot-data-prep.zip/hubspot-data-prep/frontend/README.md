# Frontend — Cellwise

Next.js (App Router) + Tailwind enterprise dashboard: drag-and-drop upload,
a live "AI Operations Terminal" that streams real per-batch processing logs,
a red/green before-after split view with fix badges, an ROI analytics
summary, and CSV export.

## Setup

```bash
cd frontend
npm install
cp .env.local.example .env.local
# edit .env.local if your backend isn't on localhost:8000
```

## Run

```bash
npm run dev
```

Visit http://localhost:3000 (make sure the backend is running on the URL set
in `NEXT_PUBLIC_API_URL`).

## Structure

- `app/page.tsx` — orchestrates the whole flow: dropzone → live SSE terminal
  → analytics summary → before/after split view → CSV export. Consumes
  `POST /api/clean-stream` directly via `fetch` + a streamed `ReadableStream`
  reader (not `EventSource`, since that can't send a file body), parsing
  Server-Sent Events as they arrive.
- `components/Dropzone.tsx` — drag-and-drop + click-to-browse, with an
  ambient emerald glow while a file is being dragged over it.
- `components/Terminal.tsx` — the "AI Operations Terminal". Every line it
  shows is real: a genuine header mapping the model found, a genuine count
  of phone numbers fixed, a genuine MX-validation result — nothing here is
  scripted flavor text.
- `components/PreviewTable.tsx` — the before/after split view. Before is
  tinted rose, after is tinted emerald, and each "after" row shows small
  badge pills (e.g. "Fixed to E.164", "Invalid Domain (no MX record)") drawn
  from the backend's real per-row analysis.
- `components/AnalyticsSummary.tsx` — the four ROI stat tiles (rows
  processed, headers auto-mapped, invalid emails caught, estimated hours
  saved), all sourced from the same real stats object as the terminal log.
- `app/globals.css` / `tailwind.config.ts` — the design tokens: deep
  slate/charcoal surfaces, a subtle blueprint-grid background, emerald as
  the primary action color, violet as the secondary/data accent, rose for
  flagged issues.

## Design notes

Palette: `canvas` #0A0D12 (page), `surface`/`surface2` (panels), `emerald`
(primary CTA + "good" signal), `violet` (secondary accent, header-mapping
lines), `rose` (flagged/invalid signal). Type: Space Grotesk (display),
Inter (body), JetBrains Mono (terminal, data cells, timestamps). The
signature element is the operations terminal itself — it exists to make the
software's real work legible to a skeptical agency COO, not to decorate the
loading state.
