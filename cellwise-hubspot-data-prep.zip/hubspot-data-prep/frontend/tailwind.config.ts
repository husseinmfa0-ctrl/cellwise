import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        canvas: "#0A0D12",
        surface: "#12161D",
        surface2: "#1A2029",
        surface3: "#212836",
        border: {
          DEFAULT: "#232A35",
          strong: "#38414F",
        },
        ink: "#EDF1F5",
        inkmuted: "#8D97A5",
        inkfaint: "#565F6C",
        emerald: {
          DEFAULT: "#17E8A0",
          dark: "#0FBE83",
          bg: "#0E2620",
        },
        violet: {
          DEFAULT: "#9C87F7",
          dark: "#7C63E8",
          bg: "#211B3B",
        },
        rose: {
          DEFAULT: "#FF6B6B",
          dark: "#E5484D",
          bg: "#2E1417",
        },
      },
      fontFamily: {
        display: ["var(--font-display)"],
        body: ["var(--font-body)"],
        mono: ["var(--font-mono)"],
      },
    },
  },
  plugins: [],
};
export default config;
