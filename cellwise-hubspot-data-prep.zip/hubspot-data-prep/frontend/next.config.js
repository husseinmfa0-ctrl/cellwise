/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Produces a minimal, self-contained server bundle in .next/standalone —
  // used by frontend/Dockerfile. Has no effect on `vercel` deploys.
  output: "standalone",
};

module.exports = nextConfig;
