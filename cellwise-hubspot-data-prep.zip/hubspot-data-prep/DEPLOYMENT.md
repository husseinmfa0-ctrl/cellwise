# Deployment Guide

Recommended setup: **frontend on Vercel**, **backend on Render or Railway**
(pick one — configs for both are included).

---

## 1. Backend — Render (recommended for simplicity)

1. Push this repo to GitHub.
2. In Render: **New → Blueprint**, point it at the repo. Render will read
   `render.yaml` at the repo root and create the `cellwise-backend` web
   service automatically (root dir `backend`, Python runtime, health check
   on `/api/health`).
3. In the service's **Environment** tab, set:
   - `GEMINI_API_KEY` — your real key (marked `sync: false` in the blueprint
     so it's not committed; you enter it in the dashboard).
   - `ALLOWED_ORIGINS` — update once you know your Vercel URL, e.g.
     `https://cellwise.vercel.app` (comma-separate multiple origins if
     needed).
4. Deploy. Note the resulting URL, e.g. `https://cellwise-backend.onrender.com`.

**Free-tier note:** Render's free web services spin down after inactivity;
the first request after idling can take ~30-50s while it wakes up. Fine for
an MVP demo, upgrade the plan before relying on it for real client onboarding
sessions.

## 1b. Backend — Railway (alternative)

1. In Railway: **New Project → Deploy from GitHub repo**.
2. Set the service's **Root Directory** to `backend`. Railway will pick up
   `backend/railway.toml` and build from `backend/Dockerfile`.
3. Add environment variables `GEMINI_API_KEY` and `ALLOWED_ORIGINS` in the
   **Variables** tab.
4. Railway auto-assigns `$PORT`; the Dockerfile and `railway.toml`
   startCommand already use it. Generate a public domain under
   **Settings → Networking**.

---

## 2. Frontend — Vercel

1. In Vercel: **Add New → Project**, import the same repo.
2. Set **Root Directory** to `frontend` (Vercel auto-detects Next.js — no
   `vercel.json` needed).
3. Add an environment variable:
   - `NEXT_PUBLIC_API_URL` = your backend URL from step 1 (e.g.
     `https://cellwise-backend.onrender.com`), for **Production**,
     **Preview**, and **Development** environments.
4. Deploy. Note the resulting URL, e.g. `https://cellwise.vercel.app`.
5. Go back to your backend's env vars and set `ALLOWED_ORIGINS` to this
   exact URL (this is what makes CORS work — the backend only accepts
   requests from origins you've explicitly listed).

---

## 3. Verify the deployed app

1. Open the Vercel URL.
2. Upload a small test `.csv`.
3. Confirm the before/after preview renders and the CSV download works.
4. If the upload hangs or errors immediately, check:
   - Browser console/network tab for CORS errors → double check
     `ALLOWED_ORIGINS` on the backend matches the frontend URL exactly
     (including `https://`, no trailing slash).
   - Backend logs (Render/Railway dashboard) for a `GEMINI_API_KEY is not
     set` or Gemini API error.

---

## Local Docker parity test (optional, before deploying)

To sanity-check both Dockerfiles together before pushing:

```bash
cp backend/.env.example backend/.env   # add your real GEMINI_API_KEY
docker compose up --build
```

Frontend at http://localhost:3000, backend at http://localhost:8000.

---

## Custom domain (later)

- Vercel: **Project → Settings → Domains**, add your domain, update DNS as
  instructed.
- Update `ALLOWED_ORIGINS` on the backend to include the new domain, and
  `NEXT_PUBLIC_API_URL` on the frontend if the backend's domain changes too.
